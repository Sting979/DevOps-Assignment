# This program runs in conjunction with database.txt config file.
# Program also pushes data with GET method
'''
The program opens database.txt file upon correct input. In case or wrong input, try-except block is used to keep on prompting user for entering the correct input.
The program stores the data of the database.txt file inside an array.
Further this program searches for the "server" word inside the data of the file
The rationale behind this is that if the basic database.txt file is appended by user then the position of the server word may change.
The program divides data of the file in two segments, first: database segment; second: server segment
Further, subelements of the file are filtered by finding "=" sign, this ensures that any unrequired data inside the file is ignored.
Then, this sub-elements are appended inside database2 file in the JSON format and same is printed in output once program is run with correct input. 
Program also pushes data with GET method
'''

def checkfile(): #checkfile function with try-except block
    fi=input("Enter File Name: ")
      
    try: # try-except block for ensuring correct input
        def openFile(): #opens file and stores input    
            f=open(fi,'r') #reading file and creating a file object
            
            a=(f.readlines()) # storing data of the file inside a list
            b=[] # sub-list for filtering the empty spaces of the file
            ll=len("server") #storing the length of the server; the word server can be changed to enable program to find any other word. The change is also required at line no-42
            f.close() #closes file to avoid any errors
            t="" # initiating temp variable for storing strings
            m=0 # temp iterator
            i=0 # temp iterator
            si=0 # temp iterator
            for i in range(len(a)):  # for loop for filtering empty spaces
                if(a[i]!="\n" or a[i]==" \n"):
                    b.append(a[i])
        # print(b) 
            
            i=0
            for x in b: # for loop for filtering string with same length as server word
                ll2=len(x)
                if(ll2>=ll):
                    while(i<len(x)-ll):
                        for j in range(i,i+ll):
                            t=t+str(x[j])
                        
                        if(t.lower()=="server"): # finding server word among filtered strings (case-insensitive)
                            si=m #saving the index of element of the list storing data of file that has the server word 
                            break; #breaking the loop    
                        #print(t)
                        
                        t=""    
                        i=i+1    
                    i=0
                m=m+1

            data=[] #sub-list
            serv=[] #sub-list
            x=0 #temp index


            for x in range(si): # for loop for storing elements of the file related to database
                data.append(b[x])
        
            for x in range(si,len(b)): # for loop for storing elements of the file related to server
                serv.append(b[x])   
            
            #print(data,serv)     
            
            data2=[] #sub-list
            data3=[] #sub-list
            d=""
            e=""
            l=0
            
            for k in range(len(data)): # for loop for filtering elements having "=" sign
                l=len(data[k])
                for r in range(l): #sub for loop
                    if(data[k][r]=="="):
                        for o in range(r-1):  #sub for loop
                            d=d+str(data[k][o])
                        data2.append(d)
                        d=""
                        for o in range(r+1,len(data[k])):
                            e=e+str(data[k][o])
                        data3.append(e)
                        e=""    
            #print(data2,data3)    
            
            serv2=[] #sub-list
            serv3=[] #sub-list
            d=""
            e=""
            l=0
            k=0
            r=0
            o=0
            
            for k in range(len(serv)): # for loop for filtering elements having "=" sign
                l=len(serv[k])
                for r in range(l): #sub for loop
                    if(serv[k][r]=="="):
                        for o in range(r-1): #sub for loop
                            d=d+str(serv[k][o])
                        serv2.append(d)
                        d=""
                        for o in range(r+1,len(serv[k])): #sub for loop
                            e=e+str(serv[k][o])
                        serv3.append(e)
                        e=""    
            #print(serv2,serv3)
            i=0 
            datanew=[]
            for i in range(len(data2)): # convering data into JSON
                d=str("-"+data2[i])+":"+str(data3[i]) 
                datanew.append(d) 
                d=""
                
            global finalData # global for accessing outside function
            finalData=[]
            finalData=["Database:\n"]+datanew   #Appending title
            #print(i,datanew,finalData)        
                
            i=0 
            servnew=[]
            for i in range(len(serv2)): # convering data into JSON
                d=str("-"+serv2[i])+":"+str(serv3[i]) 
                servnew.append(d) 
                d=""
                
            #print(serv, serv2, servnew)
            
            global finalServ # global for accessing outside function
            finalServ=[]
            finalServ=["Server:\n"]+servnew   #Appending title
            #print(finalData,finalServ)        
            
            
            
            i=0        
            f2=open("database2.txt","w") # writing data into database2 file
            f2.write("\n")
            for i in range(len(finalData)): 
                f2.write(finalData[i])
            f2.close()
            
            i=0
            f2=open("database2.txt","a") # appending data into database2 file
            f2.write("\n")
            for i in range(len(finalServ)):
                f2.write(finalServ[i])
            
            f2=open("database2.txt","r") # reading the database2 file
            print(f2.read()) # printing the database2 file in output
             
            #f2.close()    
        openFile()   
    except: #except block   
        while(fi!="database.txt"): # while loop for accepting input until correct input is received from user.
            print('File not found and cannot be opened:')
            fi=input("Enter File Name: ")
        openFile() # runing above program after correct input  
 
 
        
checkfile() #initiates function

from flask import Flask # application for posting data on web page with GET method

app1="python_assignment_3" 

app1 = Flask(__name__)

@app1.route('/', methods=['GET'])
def printingOutput():
    return (finalData+finalServ) # printing data on webpage

if __name__ == '__main__':
    app1.run(port=3000, debug=True)